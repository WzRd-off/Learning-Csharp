﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace buy_list
{
    public partial class Form1 : Form
    {
        // VARIABLES
        private BindingList<Dictionary<string, string>.ValueCollection> mainBuyList = new BindingList<Dictionary<string, string>.ValueCollection>();
        private Dictionary<string, decimal> statistic = new Dictionary<string, decimal>();
        private Stack<List<Dictionary<string, string>>> 
            undo = new Stack<List<Dictionary<string, string>>>(), 
            redo = new Stack<List<Dictionary<string, string>>>();

        public Form1()
        {
            InitializeComponent();
            
            dgvBuyList.Columns.Add("Name","Ім'я");
            dgvBuyList.Columns.Add("Category", "Категорія");
            dgvBuyList.Columns.Add("Price", "Ціна");
            dgvBuyList.Columns.Add("Data", "Дата");
            dgvBuyList.Columns.Add("Bought", "Куплено");
            dgvBuyList.AllowUserToAddRows = false;
            dgvBuyList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBuyList.ReadOnly = true;

            dgvBuyList.DataSource = mainBuyList;
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {

        }

        private void btnRedo_Click(object sender, EventArgs e)
        {

        }

        private void btnProductAdd_Click(object sender, EventArgs e)
        {
            if (tbProductName.Text.Length == 0) { 
                MessageBox.Show("Ім'я продукту не може бути пустим!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (cbProductCategory.SelectedItem == null) {
                MessageBox.Show("Категорія не може бути не вибрана!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (tbProductPrice.Text.Length == 0) {
                MessageBox.Show("Ціна продукту не може бути пустою!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Dictionary<string, string> newProduct = new Dictionary<string, string>();
            newProduct["Name"] = tbProductName.Text;
            newProduct["Category"] = cbProductCategory.SelectedItem.ToString();
            newProduct["Price"] = tbProductPrice.Text;
            newProduct["Data"] = dtpProductDate.Value.ToShortDateString();
            newProduct["Bought"] = cbProductBought.Checked.ToString();

            mainBuyList.Add(newProduct.Values);


            dgvBuyList.Refresh();
            //UpdateDgv(mainBuyList);

            tbProductName.Clear();
            tbProductPrice.Clear();
            cbProductCategory.SelectedItem = null;
            cbProductBought.Checked = false;
        }

        private void btnProductChange_Click(object sender, EventArgs e)
        {
            if (mainBuyList == null) {
                MessageBox.Show("Список покупок пустий!\n Немає що редагувати", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnProductRemove_Click(object sender, EventArgs e)
        {
            if (mainBuyList == null)
            {
                MessageBox.Show("Список покупок пустий!\n Немає що видаляти", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearchName_Click(object sender, EventArgs e)
        {
            if (tbSearchName.Text.Length == 0)
            {
                MessageBox.Show("Пошукова строка не може бути пустою!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            if (cbSortType.SelectedItem == null)
            {
                MessageBox.Show("Категорія не може бути не обрана!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            if (clbFilterCategory.CheckedItems.Count == 0)
            {
                MessageBox.Show("Категорія не може бути не обрана!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOpenStatistic_Click(object sender, EventArgs e)
        {
            StatisticForm f = new StatisticForm();
            f.Show();
        }

        private void tbProductPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back) { 
            e.Handled = true;
            }
        }

        private void UpdateDgv(IBindingList listToShow)
        {
            dgvBuyList.Rows.Clear();

            foreach (Dictionary<string, string> product in listToShow)
            {
                dgvBuyList.Rows.Add(
                    product["Name"],
                    product["Category"],
                    product["Price"],
                    product["Data"],
                    product["Bought"]
                );
            }
        }
    }
}